function deleteSelected() {
    $.each($(".Selected"), function () {
        this.remove();
    });
}


function copyElement(x, y) {
    y.insertBefore(x.cloneNode(true), x.nextSibling);
}