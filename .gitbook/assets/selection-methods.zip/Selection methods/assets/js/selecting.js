//global vars
var LastSelected;

//global functions
function IsInside(el, parent) {
    if ($(parent).find(el).length == 1)
        return true;
    else
        return false;

}

function deselectAll(exeption) {
    var all = $('.Selected');

    for (i = 0; i < all.length; i++) {
        if (all[i] != exeption) {
            $(all[i]).addClass('Deselected');
            $(all[i]).removeClass('Selected');
        }else{
            console.log('exeption found');
        }
    }
}

function selectAll(exeption) {
    var all = $('.Deselected');

    for (i = 0; i < all.length; i++) {
        if (all[i] != exeption) {
            $(all[i]).addClass('Selected');
            $(all[i]).removeClass('Deselected');
        }else{
            console.log('exeption found');
        }
    }
}

function toggle_selection(el, Old, New) {
    if (Old && New) {
        if (el.className.indexOf(Old) > -1) {
            el.className = el.className.replace(Old, New);
        }
    } else {
        console.log('toggle without old/new')
        if (el.className.indexOf('Deselected') > -1) {
            el.className = el.className.replace('Deselected', 'Selected');
            LastSelected = el;
        } else {
            el.className = el.className.replace('Selected', 'Deselected');
            LastSelected = null;
        }

    }

}


//script
$(window).click(function (e) {
    var clicked_element = e.target;
    var selectableElement = null;

    //check if clicked element is inside an element with class selectable
    if (clicked_element.className.indexOf('selectable') > -1) {
        selectableElement = clicked_element;

        //check if clicked element is selectable
    } else if ($('.selectable').find(clicked_element).length == 1) {
        //toggle selection for selectable parent element
        selectableElement = $(clicked_element).closest('.selectable')[0];

    } else if ($('.Selected').length > 0) {

        //Deselect all
        $('.Selected').addClass('Deselected');
        $('.Selected').removeClass('Selected');
        LastSelected = null;
    }

    //als er een selectable element aangeklikt is...
    if (selectableElement) {
        el = selectableElement;

        if (event.ctrlKey || event.metaKey) {
            console.log('ctrl / cmd + click');
            toggle_selection(el);
            LastSelected = el;
            
        } else if (event.shiftKey) {
            //select alle selectable elements between select all selectable between this and lastselected

            if (el == LastSelected) {
                toggle_selection(el);
                LastSelected = el;

            } else if (LastSelected) {
                console.log('select multiple');

                var toToggle = [];
                var a = 0; //keep track of start and end 

                for (i = 0; i < $(el).parent().children().length; i++) {
                    if ($(el).parent().children()[i] == el || $(el).parent().children()[i] == LastSelected) {
                        a++;
                        toToggle.push(i);
                        console.log('start/end ' + i);
                    } else if (a == 1) { //if add to array if start has been past, but end not yet
                        toToggle.push(i);
                    }
                }

                console.log(toToggle);

                for (i = 0; i < toToggle.length; i++) {
                    console.log($(el).parent().children()[toToggle[i]]);
                    toggle_selection($(el).parent().children()[toToggle[i]], 'Deselected', 'Selected');
                }

            } else {
                console.log(el)
                toggle_selection(el);
            }
        } else {
            //normal click
            LastSelected = el;
            toggle_selection(el);
            deselectAll(el);
        }
    }


});

document.addEventListener ("keydown", function (event) {
    //ctrl + a of cmd + a = select all
    if(event.metaKey && event.keyCode == 65 || event.ctrlKey && event.keyCode == 65){
        event.preventDefault();
        selectAll();
    }
    //ctrl + d of cmd + d = select all
    if(event.metaKey && event.keyCode == 68 || event.ctrlKey && event.keyCode == 68){
        event.preventDefault();
        deselectAll();
    }
    //ctrl + s of cmd + s = save
    if(event.metaKey && event.keyCode == 83 || event.ctrlKey && event.keyCode == 83){
        event.preventDefault();
        alert('pagina opslaan?')
    }
} );