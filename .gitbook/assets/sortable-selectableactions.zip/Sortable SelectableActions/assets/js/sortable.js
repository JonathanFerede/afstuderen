$(function () {
    $("#sortable").sortable();
    $("#sortable").disableSelection();
});

function copyElement(x, y) {
    y.insertBefore(x.cloneNode(true), x.nextSibling);
}


function checkAll(o) {
    var boxes = document.getElementsByTagName("input");
    for (var x = 0; x < boxes.length; x++) {
        var obj = boxes[x];
        if (obj.type == "checkbox") {
            if (obj.name != "check")
                obj.checked = o.checked;
        }
    }
}

function deleteSelected() {
    $.each($("input:checked"), function () {
        this.parentElement.remove();
    });
}
