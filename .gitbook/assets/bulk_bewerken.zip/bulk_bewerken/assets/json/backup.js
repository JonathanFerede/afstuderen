[{
    "interne_naam": "Add the Wally",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Attackle",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Avenue Pouf",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Baboesjka",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Base",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Bolleke",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Buggle-Up Beanbag",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Buggle-Up Outdoor",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Candyofnie",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Cappie-on",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Carpet Diem",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Ch-air Lounge",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Co9",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Co9 XS Velvet",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Concrete Seat",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Concrete Seat Pillow",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Cooper Cappies",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Doggielounge",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "D'r-op D'r-over",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Duo tone collection",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Edison the Giant",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Edison the Grand",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Edison the Medium",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Edison the Petit",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Edison the Petit (retailer)",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Filler",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Formitable",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Hammocks",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Headdemock Accessories and pillows",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Headdemock Parts",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Inflatable Dolly",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Inflatable Hot dog",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Jonge",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Junior Beanbag",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Junior Beanbag UK",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Klaid",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Lampie-On",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Lamzac",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Lamzac",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Lamzac L",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Lamzac L Deluxe",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Lamzac XXXL",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Lekkerplèkkuh",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Lighting accessories",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Mag-van-alles",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Metallicap",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Metallicappie",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Molecube",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Molecube Cabinet",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Nametag",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Non-Flying Carpet",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Original Beanbag",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Original Beanbag x Jordy",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Original slim velvet",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Outdoor beanbag",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Parasols",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Party Polonaise",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Pfffh Pouf",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Picnic Lounge",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Pillow Velvet Collection",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Plat-o",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Point Original Pouf",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Point Stonewashed Pouf",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Point Velvet",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Pupillow",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Pupillow cushion",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Pupillow Velvet",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Repair Buggle-Up Straps",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Repair kits (nylon fabric)",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Rockcoco",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Rock 'n Roll",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Rondeju",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Service items",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Snacklight",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Sol-mate",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Spheremaker",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Stonewashed Beanbag",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Test hoofdproduct",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Thierry Le Swinger",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Transloetje",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Trans-parents",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Tsjonge Jonge Lounge",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Tsjonge Jongetje Lounge",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Undercover",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}, {
    "interne_naam": "Xmas Cooper Cappies",
    "omschrijving": "productbeschrijving",
    "materiaal": "katoen"
}]
