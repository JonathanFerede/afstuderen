/*
Selecting V2


Script voor selecteren.
Moeten werken zoals in Finder, Windows verkenner en Google Drive

opties:
Shiftclick, cmd + click, ctrl + click

shortcuts,
Select all      = CMD + a / ctrl + a
Deselect all    = CMD + d / ctrl + d
Save            = ctrl + s / cmd + s

Problemen:
- preventDefault. Moet niet werken wanneer gebruiker in een text-input bezig is
- Werkt niet wanneer er meerdere selecteerbare lijsten op één pagina staan. 



alle console.logs staan nu uit door "//"
*/

//global vars
var LastClicked;

//global functions
function IsInside(el, parent) {
    if ($(parent).find(el).length == 1)
        return true;
    else
        return false;

}

function deselectAll(exeption) {
    var all = $('.Selected');

    for (i = 0; i < all.length; i++) {
        if (all[i] != exeption) {
            $(all[i]).addClass('Deselected');
            $(all[i]).removeClass('Selected');
        } else {
            //console.log('exeption found');
        }
    }
}

function selectAll(exeption) {
    var all = $('.Deselected');

    for (i = 0; i < all.length; i++) {
        if (all[i] != exeption) {
            $(all[i]).addClass('Selected');
            $(all[i]).removeClass('Deselected');
        } else {
            //console.log('exeption found');
        }
    }
}

function toggle_selection(el, Old, New) {
    if (Old && New) {
        if (el.className.indexOf(Old) > -1) {
            el.className = el.className.replace(Old, New);
        }
    } else {
        //console.log('toggle without old/new')
        if (el.className.indexOf('Deselected') > -1) {
            el.className = el.className.replace('Deselected', 'Selected');
            LastClicked = el;
        } else {
            el.className = el.className.replace('Selected', 'Deselected');
            LastClicked = null;
        }

    }

}


//script
$(window).click(function (e) {
    var clicked_element = e.target;
    var selectableElement = null;

    //check if clicked element is inside an element with class selectable
    if (clicked_element.className.indexOf('selectable') > -1) {
        selectableElement = clicked_element;

        //check if clicked element is selectable
    } else if ($('.selectable').find(clicked_element).length == 1) {
        //toggle selection for selectable parent element
        selectableElement = $(clicked_element).closest('.selectable')[0];

    } else if ($('.Selected').length > 0) {

        //Deselect all
        $('.Selected').addClass('Deselected');
        $('.Selected').removeClass('Selected');
        LastClicked = null;
    }

    //als er een selectable element aangeklikt is...
    if (selectableElement) {
        el = selectableElement;

        if (event.ctrlKey || event.metaKey) {
            //console.log('ctrl / cmd + click');
            toggle_selection(el);
            LastClicked = el;

        } else if (event.shiftKey) {
            //select alle selectable elements between select all selectable between this and LastClicked

            //if last clicked was selected -> select them. If deselected -> deselect them

            if (el == LastClicked) {
                toggle_selection(el);
                LastClicked = el;

            } else if (LastClicked) {


                var toToggle = [];
                var a = 0; //keep track of start and end 

                for (i = 0; i < $(el).parent().children().length; i++) {
                    if ($(el).parent().children()[i] == el || $(el).parent().children()[i] == LastClicked) {
                        a++;
                        toToggle.push(i);
                        //console.log('start/end ' + i);
                    } else if (a == 1) { //if add to array if start has been past, but end not yet
                        toToggle.push(i);
                    }
                }


                //console.log(toToggle);


                if (LastClicked.className.indexOf('Selected') > -1) {
                    //console.log('Select multiple')
                    for (i = 0; i < toToggle.length; i++) {
                        //                        //console.log($(el).parent().children()[toToggle[i]]);
                        toggle_selection($(el).parent().children()[toToggle[i]], 'Deselected', 'Selected');
                    }
                } else {
                    //console.log('Deselect multiple')
                    for (i = 0; i < toToggle.length; i++) {
                        //                        //console.log($(el).parent().children()[toToggle[i]]);
                        toggle_selection($(el).parent().children()[toToggle[i]], 'Selected', 'Deselected');
                    }
                }

            } else {
                //                //console.log(el)
                toggle_selection(el);
            }
        } else {
            //normal click
            LastClicked = el;
            toggle_selection(el, 'Deselected', 'Selected');
            deselectAll(el);
        }
    }


});

document.addEventListener("keydown", function (event) {
    //ctrl + a of cmd + a = select all
    if (event.metaKey && event.keyCode == 65 || event.ctrlKey && event.keyCode == 65) {
        event.preventDefault();
        selectAll();
    }
    //ctrl + d of cmd + d = select all
    if (event.metaKey && event.keyCode == 68 || event.ctrlKey && event.keyCode == 68) {
        event.preventDefault();
        deselectAll();
    }
    //ctrl + s of cmd + s = save
    if (event.metaKey && event.keyCode == 83 || event.ctrlKey && event.keyCode == 83) {
        event.preventDefault();
        alert('pagina opslaan?')
    }
});
