/*


First the jsonfile will be loaded
Then, when document is ready, the page will be drawn


Callback functies en error feedback toegevoegd

ToDo:
- var products kan van alles zijn
- 
*/


var products;
var products_being_editted = [];
var path_JsonFile = "assets/json/data.json";


$(document).ready(
    load_jsonfile(ErrCallback, draw_page)
);

//load jsonfile
function load_jsonfile(err_callback, callback) {
    products = [];
    $.ajax({
        url: path_JsonFile,
        dataType: "json",
        success: function (jsonData) {
            products = jsonData;
            callback()
        },
        error: function (textStatus, errorThrown) {
            err_callback("Error getting the data")
        }
    });
}

function draw_page() {

    $('#table').html("");

    console.log('empty');

    console.log($('#table')[0]);

    if (products.length > 0) {
        products.forEach(function (product, i) {
            //console.log(product.interne_naam);
            var tr = $("<tr id='" + i + "' class='selectable Deselected'><td>" + product.interne_naam + "</td><td>" + product.omschrijving + "</td><td>" + product.materiaal + "</td></tr>");
            $('#table').append(tr);
        });

        $('#bulk_edit_btn').click(function () {
            load_bulk_edit_window(products);

        });

        $('#bulk_edit_save_btn').click(function () {

            //if saved, hide window
            if (bulk_edit_save(products)) {
                $('#edit_window').hide();
            }
        });
    } else {
        console.log('products is empty');
    }

}

function load_bulk_edit_window(data) {
    if ($('.Selected').length > 0) {

        var toEdit = [];
        var names = [];

        for (i = 0; i < $('.Selected').length; i++) {
            var el = $('.Selected')[i];
            var el_index;
            console.log(el);

            //get the index of the selected elements
            for (j = 0; j < $(el).parent().children().length; j++) {
                if ($(el).parent().children()[j] == el) {
                    el_index = j;
                    products_being_editted.push(j);
                }
            }

            console.log('index = ' + el_index);
            toEdit.push(data[el_index]);
            names.push(data[el_index].interne_naam);

        }

        console.log(toEdit);
        //loop through product properties
        for (i = 0; i < Object.values(toEdit[0]).length; i++) {

            //var el = document.createElement('input');
            var value = null;

            //get name of property
            var propertynames = [];
            for (key in toEdit[0])
                propertynames.push(key);

            //loop through products per property
            for (j = 0; j < toEdit.length; j++) {

                if (value != 'variable') {
                    if (value == null) {
                        value = Object.values(toEdit[j])[i];
                    } else if (value != Object.values(toEdit[j])[i]) {
                        value = 'variable';
                    }
                }
            }

            //feedback aan gebruiker wanneer een veld wel of niet veranderd is en geupdatet zal worden
            var onchangeScript = "if(this.value != '" + value + "'){this.parentElement.parentElement.className = this.parentElement.parentElement.className.replace('unchanged','changed')}else{this.parentElement.parentElement.className = this.parentElement.parentElement.className.replace('changed','unchanged')}";
            var el = '<input id="property' + i + '" type="text" name="' + propertynames[i] + '" value="' + value + '" oninput="' + onchangeScript + '"></input>';

            //create input
            $('#edit_window section').append('<tr class="unchanged"><td><label for="' + 'property' + i + '">' + propertynames[i] + '</label></td><td>' + el + '</td><td><button data-default-value="' + value + '" class="resetBtn">reset</button></td></tr>');

            //function to reset value of inputfield
            $('#edit_window section .resetBtn').click(function () {
                this.parentElement.previousSibling.firstChild.value = $(this).attr('data-default-value');
                $(this.parentElement.previousSibling.firstChild).trigger("input");
            })
        }
        $('#edit_window h1').append(names.length + ' items geselecteerd');

        //console.log(toEdit);
        $('#edit_window').show();

    } else {
        alert('nothing selected')
    }
}


function bulk_edit_save() {
    console.log('save');
    //find all changed variables with the right destination

    //doe alleen iets als er iets veranderd is
    if ($('#edit_window section .changed').length > 0) {
        var inputfields = $('#edit_window section .changed input');

        console.log(inputfields.length + ' fields have been changed');

        //loop door changed inputfields
        for (i = 0; i < inputfields.length; i++) {
            console.log(products_being_editted[i]);
            var n = $(inputfields[i]).attr('name');
            var v = $(inputfields[i]).val();

            //loop through objects and update value
            for (j = 0; j < products_being_editted.length; j++) {
                products[products_being_editted[j]][n] = v;
            }
        }
    }

    updateJsonFile(path_JsonFile, products, ErrCallback, load_jsonfile);

    $('#edit_window section').html("");;
    $('#edit_window h1').html("");;
    products_being_editted = [];
    return true;
}


function updateJsonFile(Path, newdata, err_callback, callback) {

    //    console.log(Path);
    //    console.log(newdata);
    //    console.log(products);

    var Succes = false;
    $.ajax({
        type: "POST",
        url: 'save_json.php',
        data: {
            data: JSON.stringify(newdata),
            path: Path
        },
        success: function () {
            callback(ErrCallback, draw_page);
        },
        error: function (textStatus, errorThrown) {
            err_callback(errorThrown)
        }
    });
}


function ErrCallback(x) {
    console.log(x);
}
