function correctField() {
    $('#search_bulk').val($('#search_bulk').val().split(/[\r\n,]/g));
}

$(document).ready(function () {

    $("#search").on("keyup", function () {
        var value = $(this).val();

        $("table tr").each(function (index) {
            if (index != 0) {

                $row = $(this);

                var sku = $row.find("td:first").text();

                if (sku.indexOf(value) < 0) {
                    $(this).hide();
                } else {
                    $(this).show();
                }
            }
        });
    });

    //in dit geval is value een array 
    $("#search_bulk").on("keyup", function () {
        var value = $(this).val().split(' ');

        $("table tr").each(function (index) {
            if (index != 0) {

                $row = $(this);

                var id = $row.find("td:first").text();

                //check if the text in this td is in the array of value's
                if (value.includes(id)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            }
        });
    });
});
