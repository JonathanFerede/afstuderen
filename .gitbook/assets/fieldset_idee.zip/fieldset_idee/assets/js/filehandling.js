//load jsonfile. The data will return with the callback function
function load_jsonfile(Path, callback) {
    $.ajax({
        url: Path,
        dataType: "json",
        success: function (jsonData) {
            callback(jsonData);
        },
        error: function (textStatus, errorThrown) {
            ErrCallback(textStatus);
            ErrCallback(errorThrown);
        }
    });
}

function updateJsonFile(Path, newdata, ErrCallback, callback) {

    //    console.log(Path);
    //    console.log(newdata);
    //    console.log(products);

    var Succes = false;
    $.ajax({
        type: "POST",
        url: 'save_json.php',
        data: {
            data: JSON.stringify(newdata),
            path: Path
        },
        success: function () {
            callback(ErrCallback, callback);
        },
        error: function (textStatus, errorThrown) {
            ErrCallback(errorThrown)
        }
    });
}

function ErrCallback(x) {
    console.log(x);
}
