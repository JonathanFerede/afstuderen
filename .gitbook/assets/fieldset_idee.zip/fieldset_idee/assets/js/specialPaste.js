function specialPaste(fieldset) {
    var el = document.createElement('div');
    $(el).attr('id', 'specialPastePopup');

    var txtarea = document.createElement('TEXTAREA');
    $(txtarea).attr('autofocus', 'true');
    $(txtarea).attr('placeholder', 'plak hier je data vanuit excel of een andere tabel');
    $(el).append(txtarea);

    var submit = document.createElement('div');
    $(submit).addClass('button');
    $(submit).append(document.createTextNode("Paste"));
    $(submit).attr('onclick', 'paste(' + fieldset.id + ')');
    $(el).append(submit);

    var cancel = document.createElement('div');
    $(cancel).addClass('button');
    $(cancel).append(document.createTextNode("Cancel"));
    $(cancel).attr('onclick', 'cancel()');
    $(el).append(cancel);

    $('body').prepend(el)
}

function paste(fieldsetID) {
    var str = $('#specialPastePopup textarea')[0].value.split(/[\r\n]/g);

    $('#' + fieldsetID.id + " input:text").each(function (i) {
        $('#' + fieldsetID.id + " input:text")[i].value = str[i];
    });

    $('#specialPastePopup').remove();
}

function cancel() {
    $('#specialPastePopup').remove();
}
