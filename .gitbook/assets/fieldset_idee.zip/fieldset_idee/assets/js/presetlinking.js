/*
wanneer de pagina geladen is word de jsonfile geladen.
De callback (init_presets) krijgt de jsondata mee.
de jsondata word in de global var presets gezet. 


*/


//global vars
var colors;

$(document).ready(load_jsonfile('assets/json/colors.json', init_presetlinking));

function init_presetlinking(x) {
    colors = x.colors;

    //console.log(colors);
    for (i in colors) {
        //colors[i].EN
        //console.log(colors[i])

        var option = document.createElement('option');
        $(option).append(document.createTextNode(colors[i].EN));
        $(option).attr('value', i);

        $('select#colors').append(option)
    }

    $('select#colors').attr('onchange', 'showPreview()');
}

function showPreview() {
    //console.log($('select#colors').val())
    //console.log(colors[$('select#colors').val()])

    var output;
    if (colors[$('select#colors').val()])
        output = JSON.stringify(colors[$('select#colors').val()], null, '\t').toString();
    else
        output = '';
    $('#preview').text(output);
}
