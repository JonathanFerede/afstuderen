/*
wanneer de pagina geladen is word de jsonfile geladen.
De callback (init_presets) krijgt de jsondata mee.
de jsondata word in de global var presets gezet. 


*/


//global vars
var presets;
var jsonfilepath = 'assets/json/presets.json'

$(document).ready(load_jsonfile(jsonfilepath, init_presets));

function init_presets(x) {
    presets = x;

    //search for presets that belong to all fieldsets with presets-on
    for (i = 0; i < $('fieldset.presets-on').length; i++) {
        var id = $('fieldset.presets-on')[i].id;




        //create div for all preset elements
        var presetdiv = document.createElement("div");
        $(presetdiv).addClass('presetDiv');

        //create new_preset button
        var newpresetBtn = document.createElement("div");
        $(newpresetBtn).addClass('button newPresetBtn');
        $(newpresetBtn).attr('onclick', 'createNewPreset(' + id + ')');

        var plus = document.createElement("i");
        $(plus).addClass('fas fa-plus-circle');
        $(newpresetBtn).append(plus);

        var span = document.createElement("span");
        $(span).append(document.createTextNode("New preset"));
        $(newpresetBtn).append(span);
        $(presetdiv).append(newpresetBtn);

        //create specialPasteBtn
        var specialPasteBtn = document.createElement("div");
        $(specialPasteBtn).addClass('button specialPasteBtn');
        $(specialPasteBtn).attr('onclick', 'specialPaste(' + id + ')');

        var paste = document.createElement("i");
        $(paste).addClass('far fa-clipboard');
        $(specialPasteBtn).append(paste);

        var span = document.createElement("span");
        $(span).append(document.createTextNode("Special Paste"));
        $(specialPasteBtn).append(span);
        $(presetdiv).append(specialPasteBtn);

        //check for existing presets
        if (presets[id]) {
            console.log(presets[id].length + ' preset(s) found for ' + id);

            var ul = document.createElement("ul");

            //create for every preset...
            for (j = 0; j < presets[id].length; j++) {
                var li = document.createElement("li");
                $(li).addClass('button');

                var span = document.createElement("span");
                $(span).append(document.createTextNode(presets[id][j].name));
                $(span).attr('onclick', 'applyPreset(' + id + ',' + j + ')');
                $(li).append(span);

                var renameBtn = document.createElement("i");
                $(renameBtn).addClass('far fa-edit');
                $(renameBtn).attr('onclick', 'renamePreset(' + id + ',' + j + ')');
                $(li).append(renameBtn);

                var updateBtn = document.createElement("i");
                $(updateBtn).addClass('fas fa-sync-alt');
                $(updateBtn).attr('onclick', 'updatePreset(' + id + ',' + j + ')');
                $(li).append(updateBtn);

                var delBtn = document.createElement("i");
                $(delBtn).addClass('far fa-trash-alt');
                $(delBtn).attr('onclick', 'deletePreset(' + id + ',' + j + ')');
                $(li).append(delBtn);

                $(ul).append(li);
            }

            $(presetdiv).append(ul);

        } else {
            console.log('no preset found for ' + id);
        }

        $('fieldset.presets-on')[i].prepend(presetdiv);

    }
}


function createNewPreset(fieldset) {
    /*om de een of andere reden komt de id niet als string binnen 
    Maar als het hele element. Ik snap niet waarom dit werkt, maar het werkt*/


    var name = prompt("Name this new preset", "Preset1");
    if (name == null || name == "") {
        //"User cancelled the prompt.";
    } else {

        console.log(name);
        console.log(fieldset.id);
        console.log($('#' + fieldset.id + ' input').length);

        //create preset object
        if (presets[fieldset.id] == undefined)
            presets[fieldset.id] = [];

        preset = {
            name: name,
            data: {}
        };

        for (i = 0; i < $('#' + fieldset.id + ' input').length; i++) {

            var input = $('#' + fieldset.id + ' input')[i];



            if ($(input).attr('type') == 'checkbox' || $(input).attr('type') == 'radio')
                if ($(input).is(":checked"))
                    var value = 'checked';
                else
                    var value = 'unchecked';
            else
                var value = String($(input).val());

            preset.data[input.id] = value;
            //presets[fieldset.id][input.id] = value;
            //console.log(presets[fieldset.id][input.id]);
        }
        presets[fieldset.id].push(preset);

        console.log(JSON.stringify(presets));

        updateJsonFile(jsonfilepath, presets, ErrCallback, reload);
    }
}

function reload() {
    if (confirm("are you sure you want to reload?"))
        location.reload(true);
}

function applyPreset(fieldset, presetIndex) {
    console.log('apply preset ' + presets[fieldset.id][presetIndex].name);
    console.log(fieldset);
    var data = presets[fieldset.id][presetIndex].data;

    //loop door alle inputs in deze fieldset
    for (i = 0; i < $('#' + fieldset.id + ' input').length; i++) {
        var input = $('#' + fieldset.id + ' input')[i];

        //console.log('type: ' + $(input).attr('type') + ' id: ' + data[input.id]);


        if ($(input).attr('type') == 'checkbox' || $(input).attr('type') == 'radio') {

            if (data[input.id] == 'checked')
                $(input).prop("checked", true)
            if (data[input.id] == 'unchecked')
                $(input).prop("checked", false)

        } else
            $(input).val(data[input.id]);
    }


}

function updatePreset(fieldset, presetIndex) {
    console.log('updatePreset');
    console.log(presets[fieldset.id][presetIndex]);

    var data = presets[fieldset.id][presetIndex].data;

    //loop door alle inputs in deze fieldset
    for (i = 0; i < $('#' + fieldset.id + ' input').length; i++) {
        var input = $('#' + fieldset.id + ' input')[i];

        console.log('type: ' + $(input).attr('type') + ' id: ' + data[input.id]);

        var value;
        if ($(input).attr('type') == 'checkbox' || $(input).attr('type') == 'radio') {
            if ($(input).is(":checked"))
                value = 'checked';
            else
                value = 'unchecked';
        } else
            value = $(input).val();
        data[input.id] = value;
    }
    presets[fieldset.id][presetIndex].data = data;
    updateJsonFile(jsonfilepath, presets, ErrCallback, reload);
}

function deletePreset(fieldset, presetIndex) {
    console.log('deletePreset');
    console.log(presets[fieldset.id][presetIndex]);
    presets[fieldset.id].splice(presetIndex, 1);


    updateJsonFile(jsonfilepath, presets, ErrCallback, reload);

}

function renamePreset(fieldset, presetIndex) {
    console.log('rename ' + presets[fieldset.id][presetIndex].name);

    presets[fieldset.id][presetIndex].name = prompt("Rename preset", presets[fieldset.id][presetIndex].name);

    updateJsonFile(jsonfilepath, presets, ErrCallback, reload);
}
