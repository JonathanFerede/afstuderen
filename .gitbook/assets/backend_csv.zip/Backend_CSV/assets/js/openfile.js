var path_JsonFile = "assets/json/csvjson.json";
var data;
var newdata = [];

function parseData(x) {

}

$(document).ready(
    load_csvfile('assets/csv/paginas.csv', function (x) {
        //parseData(x);

        console.log(x)

    })
);
