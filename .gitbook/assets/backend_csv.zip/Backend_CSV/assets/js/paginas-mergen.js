//Pagina vertalingen mergen
var CSV_files = [
["da", "assets/csv/paginas-da.csv"],
["de", "assets/csv/paginas-de.csv"],
["en", "assets/csv/paginas-en.csv"],
["es", "assets/csv/paginas-es.csv"],
["fr", "assets/csv/paginas-fr.csv"],
["it", "assets/csv/paginas-it.csv"],
["nl", "assets/csv/paginas-nl.csv"],
["sv", "assets/csv/paginas-sv.csv"]
                ];

var pages = [];
var PagesSorted = []

$(document).ready(function () {

    var filesLoaded = 0;
    for (i = 0; i < CSV_files.length; i++) {
        load_csvfile(CSV_files[i][1], function (x) {

            //save data from translation in pages[translation]
            pages[CSV_files[filesLoaded][0]] = csvJSON(x);

            filesLoaded += 1;
            //when all files are loaded...
            if (filesLoaded == CSV_files.length)
                parseData(x);
        });
    }
})

function parseData(x) {

    //loop through languages
    for (h = 0; h < CSV_files.length; h++) {
        var lang = CSV_files[h][0];
        //console.log(lang);

        //loop through pages per language
        for (i = 0; i < pages[lang].length; i++) {
            //console.log(pages[lang][i].id);
            if (PagesSorted[pages[lang][i].id] === undefined)
                PagesSorted[pages[lang][i].id] = [];

            //
            if (pages[lang][i].key.indexOf('component') > -1) {

                var componentID = pages[lang][i].key.split('.')[1]
                var contentType = pages[lang][i].key.split('.')[2];
                var contentval = pages[lang][i].value;

                //check of the page id already has components
                if (PagesSorted[pages[lang][i].id].components === undefined)
                    PagesSorted[pages[lang][i].id].components = [];

                //check if this component already exists
                if (PagesSorted[pages[lang][i].id].components[componentID] === undefined)
                    PagesSorted[pages[lang][i].id].components[componentID] = [];

                //check if this component contenttype already exists
                if (PagesSorted[pages[lang][i].id].components[componentID][contentType] === undefined)
                    PagesSorted[pages[lang][i].id].components[componentID][contentType] = [];

                var obj = [];
                obj[lang] = contentval
                PagesSorted[pages[lang][i].id].components[componentID][contentType].push(obj);

            } else {
                if (PagesSorted[pages[lang][i].id][pages[lang][i].key] === undefined) {
                    PagesSorted[pages[lang][i].id][pages[lang][i].key] = [];
                }
                var obj = [];
                obj[lang] = pages[lang][i].value
                PagesSorted[pages[lang][i].id][pages[lang][i].key].push(obj);
            }
        }
    }

    for (i = 0; i < PagesSorted.length; i++) {
        if (PagesSorted[i] === undefined) {
            PagesSorted[i] = 'empty';
        }
    }

    console.log(PagesSorted);

    /*updateJsonFile('assets/PagesSorted.json', PagesSorted, ErrCallback, function () {
        console.log(PagesSorted);
    })*/

    //getSEOStats();
    //getComponentStats();
    newLoop()
}

function getSEOStats() {
    var pages_with_content = 0;
    var pages_with_components = 0;
    var titles = [];
    var titles_transl = 0;
    var descriptions = [];
    var descriptions_transl = 0;

    //SEO
    //Hoevaak worden Titels, Beschrijvingen, Keywords, Afbeeldingen ingevuld?
    for (i = 0; i < PagesSorted.length; i++) {

        if (PagesSorted[i] != 'empty') {
            pages_with_content++;
            for (j = 0; j < Object.keys(PagesSorted[i]).length; j++) {

                if (Object.keys(PagesSorted[i])[j].indexOf("components") > -1) {
                    pages_with_components++;
                }

                //SEO
                if (Object.keys(PagesSorted[i])[j].indexOf("seo") > -1) {
                    //console.log(Object.keys(PagesSorted[i])[j].split('.')[1])

                    if (Object.keys(PagesSorted[i])[j].indexOf('titles') > -1) {
                        for (k = 0; k < PagesSorted[i][Object.keys(PagesSorted[i])[j]].length; k++) {
                            if (PagesSorted[i][Object.keys(PagesSorted[i])[j]][k]) {
                                if (PagesSorted[i][Object.keys(PagesSorted[i])[j]][k].en) {
                                    titles.push(PagesSorted[i][Object.keys(PagesSorted[i])[j]][k].en);
                                }
                            }
                        }
                        titles_transl += PagesSorted[i][Object.keys(PagesSorted[i])[j]].length;

                    } else if (Object.keys(PagesSorted[i])[j].indexOf('descriptions') > -1) {
                        for (k = 0; k < PagesSorted[i][Object.keys(PagesSorted[i])[j]].length; k++) {
                            if (PagesSorted[i][Object.keys(PagesSorted[i])[j]][k]) {
                                if (PagesSorted[i][Object.keys(PagesSorted[i])[j]][k].en) {
                                    descriptions.push(PagesSorted[i][Object.keys(PagesSorted[i])[j]][k].en);
                                }
                            }
                        }
                        descriptions_transl += PagesSorted[i][Object.keys(PagesSorted[i])[j]].length;
                    }
                }
            }
        }
    }
    console.log('\n\n------------titles------------\n\n')
    for (a = 0; a < titles.length; a++) {
        console.log(titles[a])
    }
    console.log('\n\n----------descriptions--------\n\n')
    for (a = 0; a < descriptions.length; a++) {
        console.log(descriptions[a])
    }
    console.log('componentNames')
    var componentNames = [];
    for (a = 0; a < PagesSorted.length; a++)
        if (PagesSorted[a] && PagesSorted[a].components)
            for (b = 0; b < Object.keys(PagesSorted[a].components).length; b++)
                componentNames.push(Object.keys(PagesSorted[a].components)[b])

    componentNames.sort();
    for (a = 0; a < componentNames.length; a++)
        console.log(componentNames[a])
    console.log('componentNames')

    console.log('pages: ' + PagesSorted.length)
    console.log('pages with content: ' + pages_with_content)
    console.log('pages with components: ' + pages_with_components)
    //console.log('titles: ' + titles)
    console.log('titles_transl: ' + titles_transl)
    //console.log('descriptions: ' + descriptions)
    console.log('descriptions_transl: ' + descriptions_transl)
    console.log('avg tr titles: ' + titles_transl / titles)
    console.log('avg tr descriptions: ' + descriptions_transl / descriptions)

}

function getComponentStats() {
    var component_att = [];
    var nrOfComponents = 0;
    var button_title = {
        translations: 0,
        content: []
    };
    var buy_now_title = {
        translations: 0,
        content: []
    };
    var content_header = {
        translations: 0,
        content: []
    };
    var content_text = {
        translations: 0,
        content: []
    };
    var introtext = {
        translations: 0,
        content: []
    };
    var onderwerp = {
        translations: 0,
        content: []
    };
    var ontvanger = {
        translations: 0,
        content: []
    };
    var subtitle = {
        translations: 0,
        content: []
    };
    var title = {
        translations: 0,
        content: []
    };
    var video = {
        translations: 0,
        content: []
    };

    //loop through pages
    for (i = 0; i < PagesSorted.length; i++) {

        //if they're not empty
        if (PagesSorted[i] != 'empty') {

            //loop through page attributes
            for (j = 0; j < Object.keys(PagesSorted[i]).length; j++) {
                var att = Object.keys(PagesSorted[i])[j];

                //look for components
                if (att.indexOf("component") > -1) {
                    //show found components
                    //console.log(PagesSorted[i][att])

                    nrOfComponents += Object.keys(PagesSorted[i][att]).length;

                    //loop through all the found components
                    for (k = 0; k < Object.keys(PagesSorted[i][att]).length; k++) {
                        var component = PagesSorted[i][att][Object.keys(PagesSorted[i][att])[k]]

                        //arr.push(Object.keys(component))


                        for (l = 0; l < Object.keys(component).length; l++) {
                            if (Object.keys(component)[l] == 'button_title') {
                                button_title.translations += component[Object.keys(component)[l]].length;
                                button_title.content.push(component[Object.keys(component)[l]][2].en)
                            }
                            if (Object.keys(component)[l] == 'buy_now_title') {
                                buy_now_title.translations += component[Object.keys(component)[l]].length;
                                buy_now_title.content.push(component[Object.keys(component)[l]][0].en)
                            }
                            if (Object.keys(component)[l] == 'content-header') {
                                content_header.translations += component[Object.keys(component)[l]].length;
                                content_header.content.push(component[Object.keys(component)[l]][2].en)
                            }
                            if (Object.keys(component)[l] == 'content-text') {
                                content_text.translations += component[Object.keys(component)[l]].length;
                                content_text.content.push(component[Object.keys(component)[l]][2].en)
                            }
                            if (Object.keys(component)[l] == 'introtext') {
                                introtext.translations += component[Object.keys(component)[l]].length;
                                introtext.content.push(component[Object.keys(component)[l]][2].en)
                            }
                            if (Object.keys(component)[l] == 'onderwerp') {
                                onderwerp.translations += component[Object.keys(component)[l]].length;
                                onderwerp.content.push(component[Object.keys(component)[l]][2].en)
                            }
                            if (Object.keys(component)[l] == 'ontvanger') {
                                ontvanger.translations += component[Object.keys(component)[l]].length;
                                ontvanger.content.push(component[Object.keys(component)[l]][2].en)
                            }
                            if (Object.keys(component)[l] == 'subtitle') {
                                subtitle.translations += component[Object.keys(component)[l]].length;
                                subtitle.content.push(component[Object.keys(component)[l]][2].en)
                            }
                            if (Object.keys(component)[l] == 'title') {
                                title.translations += component[Object.keys(component)[l]].length;
                                title.content.push(component[Object.keys(component)[l]][2].en)
                            }
                            if (Object.keys(component)[l] == 'video') {
                                video.translations += component[Object.keys(component)[l]].length;
                                video.content.push(component[Object.keys(component)[l]][2].en)
                            }

                        }

                    }
                    //console.log(PagesSorted[i][Object.keys(PagesSorted[i])[j]]);
                }
            }
        }
    }


    console.log('nrOfComponents ' + nrOfComponents);
    console.log('button_title no. components: ' + button_title.content.length + ' no. translations ' + button_title.translations + ' AVG' + button_title.translations / button_title.content.length)
    console.log('buy_now_title no. components: ' + buy_now_title.content.length + ' no. translations ' + buy_now_title.translations + ' AVG' + buy_now_title.translations / buy_now_title.content.length)
    console.log('content_header no. components: ' + content_header.content.length + ' no. translations ' + content_header.translations + ' AVG' + content_header.translations / content_header.content.length)
    console.log('content_text no. components: ' + content_text.content.length + ' no. translations ' + content_text.translations + ' AVG' + content_text.translations / content_text.content.length)
    console.log('introtext no. components: ' + introtext.content.length + ' no. translations ' + introtext.translations + ' AVG' + introtext.translations / introtext.content.length)
    console.log('onderwerp no. components: ' + onderwerp.content.length + ' no. translations ' + onderwerp.translations + ' AVG' + onderwerp.translations / onderwerp.content.length)
    console.log('ontvanger no. components: ' + ontvanger.content.length + ' no. translations ' + ontvanger.translations + ' AVG' + ontvanger.translations / ontvanger.content.length)
    console.log('subtitle no. components: ' + subtitle.content.length + ' no. translations ' + subtitle.translations + ' AVG' + subtitle.translations / subtitle.content.length)
    console.log('title no. components: ' + title.content.length + ' no. translations ' + title.translations + ' AVG' + title.translations / title.content.length)
    console.log('video no. components: ' + video.content.length + ' no. translations ' + video.translations + ' AVG' + video.translations / video.content.length)


    component_att.sort();
    console.log('component_att')
    for (z = 0; z < component_att.length; z++)
        console.log('component_att ' + component_att[z])

    console.log('-------------------V------------------------')

    button_title.content.sort();
    console.log('button_title ' + button_title.content.length + ' AVG No tr: ' + button_title.translations / button_title.content.length);
    for (z = 0; z < button_title.content.length; z++)
        console.log('button_title ' + button_title.content[z])


    console.log('-------------------V------------------------')
    buy_now_title.content.sort();
    console.log('buy_now_title ' + buy_now_title.content.length + ' AVG No tr: ' + buy_now_title.translations / buy_now_title.content.length);
    for (z = 0; z < buy_now_title.content.length; z++)
        console.log('buy_now_title ' + buy_now_title.content[z])


    console.log('-------------------V------------------------')
    content_header.content.sort();
    console.log('content_header ' + content_header.content.length + ' AVG No tr: ' + content_header.translations / content_header.content.length);
    for (z = 0; z < content_header.content.length; z++)
        console.log('content_header ' + content_header.content[z])


    console.log('-------------------V------------------------')
    content_text.content.sort();
    console.log('content_text ' + content_text.content.length + ' AVG No tr: ' + content_text.translations / content_text.content.length);
    for (z = 0; z < content_text.content.length; z++)
        console.log('content_text ' + content_text.content[z])


    console.log('-------------------V------------------------')
    introtext.content.sort();
    console.log('introtext ' + introtext.content.length + ' AVG No tr: ' + introtext.translations / introtext.content.length);
    for (z = 0; z < introtext.content.length; z++)
        console.log('introtext ' + introtext.content[z])


    console.log('-------------------V------------------------')
    onderwerp.content.sort();
    console.log('onderwerp ' + onderwerp.content.length + ' AVG No tr: ' + onderwerp.translations / onderwerp.content.length);
    for (z = 0; z < onderwerp.content.length; z++)
        console.log('onderwerp ' + onderwerp.content[z])


    console.log('-------------------V------------------------')
    ontvanger.content.sort();
    console.log('ontvanger ' + ontvanger.content.length + ' AVG No tr: ' + ontvanger.translations / ontvanger.content.length);
    for (z = 0; z < ontvanger.content.length; z++)
        console.log('ontvanger ' + ontvanger.content[z])


    console.log('-------------------V------------------------')
    subtitle.content.sort();
    console.log('subtitle ' + subtitle.content.length + ' AVG No tr: ' + subtitle.translations / subtitle.content.length);
    for (z = 0; z < subtitle.content.length; z++)
        console.log('subtitle ' + subtitle.content[z])


    console.log('-------------------V------------------------')
    title.content.sort();
    console.log('title ' + title.content.length + ' AVG No tr: ' + title.translations / title.content.length);
    for (z = 0; z < title.content.length; z++)
        console.log('title ' + title.content[z])


    console.log('-------------------V------------------------')
    video.content.sort();
    console.log('video ' + video.content.length + ' AVG No tr: ' + video.translations / video.content.length);
    for (z = 0; z < video.content.length; z++)
        console.log('video ' + video.content[z])

}


function newLoop() {
    var props = []

    for (page of PagesSorted) {
        for (prop of Object.keys(page)) {
            props.push(prop);
        }
    }

    props.sort()
    for (prop of props) {
        console.log(prop)
    }
}
