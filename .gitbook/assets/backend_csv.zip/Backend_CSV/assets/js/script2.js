var data;
var newdata = [];
var newnewdata = [];

function parseData(x) {
    data = csvJSON(x);
    console.log(data)

    for (i = 0; i < data.length; i++) {
        if (newdata[data[i].id] == undefined)
            newdata[data[i].id] = [];

        newdata[data[i].id][data[i].key] = data[i].value;
    }

    //fix holes
    for (i = 0; i < newdata.length; i++) {
        if (newdata[i])
            newnewdata.push(newdata[i]);
    }

    for (i = 0; i < newnewdata.length; i++) {
        var components = [];

        var keys = Object.keys(newnewdata[i]);
        for (j = 0; j < keys.length; j++) {
            var value = newnewdata[i][keys[j]];

            if (keys[j].indexOf('components') > -1) {
                keys[j] = keys[j].split('.');

                if (components[keys[j][1]] == undefined)
                    components[keys[j][1]] = [];
                components[keys[j][1]][keys[j][2]] = value;
            }
        }

        newnewdata[i]['components'] = [];
        var keys = Object.keys(components);
        for (h = 0; h < keys.length; h++) {
            newnewdata[i].components.push(components[keys[h]]);
        }

    }

    console.log(newnewdata);

}

$(document).ready(
    load_csvfile('assets/csv/paginas.csv', function (x) {
        parseData(x);

        console.log('aantal paginas o.b.v. ID ' + newdata.length);
        console.log('aantal paginas met info  ' + newnewdata.length);

        var NoComponents = 0;
        for (i = 0; i < newnewdata.length; i++) {
            if (newnewdata[i].components != undefined)
                NoComponents += newnewdata[i].components.length;
        }
        console.log('aantal componentem: ' + NoComponents)
    })
);
