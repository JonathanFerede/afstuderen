 //load jsonfile. The data will return with the callback function
 function load_jsonfile(Path, callback) {
     $.ajax({
         url: Path,
         dataType: "json",
         success: function (jsonData) {
             callback(jsonData);
         },
         error: function (textStatus, errorThrown) {
             console.log(textStatus);
             console.log(errorThrown);
         }
     });
 }

 function load_csvfile(Path, callback) {
     $.ajax({
         url: Path,
         dataType: "text",
         success: function (csvData) {
             callback(csvData);
         },
         error: function (textStatus, errorThrown) {
             console.log(textStatus);
             console.log(errorThrown);
         }
     });
 }

 function updateJsonFile(Path, newdata, ErrCallback, callback) {

     //    console.log(Path);
     //     console.log(newdata);
     //    console.log(products);

     var Succes = false;
     $.ajax({
         type: "POST",
         url: 'save_json.php',
         data: {
             data: JSON.stringify(newdata, replacer),
             path: Path
         },
         success: function () {
             console.log(newdata);
             console.log('file has been updated');
         },
         error: function (textStatus, errorThrown) {
             console.log(errorThrown)
         }
     });
 }

 function ErrCallback(x) {
     console.log(x);
 }


 function csvJSON(csv) {

     var lines = csv.split("\n")
     var result = []
     var headers = lines[0].split(",")

     lines.map(function (line, indexLine) {
         if (indexLine < 1) return // Jump header line

         var obj = {}
         var currentline = line.split(",")

         headers.map(function (header, indexHeader) {
             obj[header] = currentline[indexHeader]
         })

         result.push(obj)
     })

     result.pop() // remove the last item because undefined values

     return result // JavaScript object
 }



 function replacer(key, value) {
     if (typeof value === 'string') {
         return value.toUpperCase();
     }
     return value;
 }
