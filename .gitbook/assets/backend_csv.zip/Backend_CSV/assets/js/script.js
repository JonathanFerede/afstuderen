var path_JsonFile = "assets/json/csvjson.json";
var data;
var newdata = [];

function parseData(x) {
    data = csvJSON(x);
    console.log(data)

    for (i = 0; i < data.length; i++) {

        if (data[i].type == "VirtualProduct") {
            if (newdata.length == 0) {
                newdata.push({
                    id: data[i].id,
                    name: data[i].value
                });
            } else if (newdata[newdata.length - 1].id != data[i].id) {
                newdata.push({
                    id: data[i].id,
                    name: data[i].value
                });
            } else {
                if (newdata[newdata.length - 1][data[i].key] == undefined)
                    newdata[newdata.length - 1][data[i].key] = [];

                newdata[newdata.length - 1][data[i].key].push(data[i].value);
            }
        } else {

            if (newdata[newdata.length - 1][data[i].type] == undefined)
                newdata[newdata.length - 1][data[i].type] = [];

            newdata[newdata.length - 1][data[i].type].push(data[i].value);
        }
        console.log()

    }


    console.log(newdata);

}

function gekoppeldeproducten() {
    var aantalgekoppeldeproducten = 0;
    var most = 0;
    for (i in newdata) {
        if (newdata[i].Product) {
            aantalgekoppeldeproducten += newdata[i].Product.length;
            if (newdata[i].Product.length > most)
                most = newdata[i].Product.length;
        }
    }

    response = {
        most: most,
        nr: aantalgekoppeldeproducten
    }
    return response;
}

function most() {

}
$(document).ready(
    load_csvfile('assets/csv/producten-en.csv', function (x) {
        parseData(x);


        var aantalHProducten = newdata.length


        console.log('aantal Hoofdproducten = ' + aantalHProducten);
        console.log('aantalgekoppeldeproducten = ' + gekoppeldeproducten().nr);
        console.log('most = ' + gekoppeldeproducten().most);

        //aantal hoofdproducten sinds feb 2017
        var x = [];
        for (i in newdata)
            x.push(parseInt(newdata[i].id));

        //feb 2018 is hoofdproductID 62 aangemaakt. 
        //feb 2019 is het laatste hoofdproductID 113

        x.sort(sortNumber);
        console.log(x[x.length - 1])
    })
);

function sortNumber(a, b) {
    return a - b;
}
