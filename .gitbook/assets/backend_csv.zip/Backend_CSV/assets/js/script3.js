var totalDataSet = [];
var paginas = [];
paginas['da'] = [];
paginas['de'] = [];
paginas['en'] = [];
paginas['es'] = [];
paginas['fr'] = [];
paginas['it'] = [];
paginas['nl'] = [];
paginas['sv'] = [];


function parseData(x) {
    var data = csvJSON(x);
    var newdata = [];
    var newnewdata = [];

    for (i = 0; i < data.length; i++) {
        if (newdata[data[i].id] == undefined)
            newdata[data[i].id] = [];

        newdata[data[i].id][data[i].key] = data[i].value;
    }

    //fix holes
    for (i = 0; i < newdata.length; i++) {
        if (newdata[i])
            newnewdata.push(newdata[i]);
    }

    for (i = 0; i < newnewdata.length; i++) {
        var components = [];

        var keys = Object.keys(newnewdata[i]);
        for (j = 0; j < keys.length; j++) {
            var value = newnewdata[i][keys[j]];

            if (keys[j].indexOf('components') > -1) {
                keys[j] = keys[j].split('.');

                if (components[keys[j][1]] == undefined)
                    components[keys[j][1]] = [];
                components[keys[j][1]][keys[j][2]] = value;
            }
        }

        newnewdata[i]['components'] = [];
        var keys = Object.keys(components);
        for (h = 0; h < keys.length; h++) {
            newnewdata[i].components.push(components[keys[h]]);
        }
    }

    return newnewdata;
}

function mergeData(country, data) {

    //make the new object array
    for (i = 0; i < paginas.en.length; i++) {

        totalDataSet[i] = [];
        totalDataSet[i]['components'] = [];

        //components
        for (j = 0; j < paginas.en[i].components.length; j++) {

            var keys = Object.keys(paginas.da[i].components[j])
            var component = [];

            for (h = 0; h < keys.length; h++) {
                //console.log(i + ' ' + j + ' ' + keys[h]);

                component[keys[h]] = [];
                if (paginas.da[i].components[j] && paginas.da[i].components[j][keys[h]])
                    component[keys[h]]['da'] = paginas.da[i].components[j][keys[h]];
                if (paginas.de[i].components[j] && paginas.de[i].components[j][keys[h]])
                    component[keys[h]]['de'] = paginas.de[i].components[j][keys[h]];
                if (paginas.en[i].components[j] && paginas.en[i].components[j][keys[h]])
                    component[keys[h]]['en'] = paginas.en[i].components[j][keys[h]];
                if (paginas.es[i].components[j] && paginas.es[i].components[j][keys[h]])
                    component[keys[h]]['es'] = paginas.es[i].components[j][keys[h]];
                if (paginas.fr[i].components[j] && paginas.fr[i].components[j][keys[h]])
                    component[keys[h]]['fr'] = paginas.fr[i].components[j][keys[h]];
                if (paginas.it[i].components[j] && paginas.it[i].components[j][keys[h]])
                    component[keys[h]]['it'] = paginas.it[i].components[j][keys[h]];
                if (paginas.nl[i].components[j] && paginas.nl[i].components[j][keys[h]])
                    component[keys[h]]['nl'] = paginas.nl[i].components[j][keys[h]];
                if (paginas.sv[i].components[j] && paginas.sv[i].components[j][keys[h]])
                    component[keys[h]]['sv'] = paginas.sv[i].components[j][keys[h]];
            }

            //andere data is minder belangrijk
            totalDataSet[i]['components'].push(component);

        }
    }

    console.log(totalDataSet);
}

$(document).ready(function () {
    load_csvfile('assets/csv/producten-da.csv', function (x) {
        paginas.da = parseData(x);
        console.log('da: ');
        console.log(paginas.da[0]);
    });

    load_csvfile('assets/csv/producten-de.csv', function (x) {
        paginas.de = parseData(x);
        console.log('de: ');
        console.log(paginas.de[0]);
    });

    load_csvfile('assets/csv/producten-en.csv', function (x) {
        paginas.en = parseData(x);
        console.log('en: ');
        console.log(paginas.en[0]);
    });

    load_csvfile('assets/csv/producten-es.csv', function (x) {
        paginas.es = parseData(x);
        console.log('es: ');
        console.log(paginas.es[0]);
    });

    load_csvfile('assets/csv/producten-fr.csv', function (x) {
        paginas.fr = parseData(x);
        console.log('fr: ');
        console.log(paginas.fr[0]);
    });

    load_csvfile('assets/csv/producten-it.csv', function (x) {
        paginas.it = parseData(x);
        console.log('it: ');
        console.log(paginas.it[0]);
    });

    load_csvfile('assets/csv/producten-nl.csv', function (x) {
        paginas.nl = parseData(x);
        console.log('nl: ');
        console.log(paginas.nl[0]);
    });

    load_csvfile('assets/csv/producten-sv.csv', function (x) {
        paginas.sv = parseData(x);
        console.log('sv: ');
        console.log(paginas.sv[0]);
    });


});
