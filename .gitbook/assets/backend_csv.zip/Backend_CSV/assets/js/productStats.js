//Pagina vertalingen mergen
var CSV_files = [
["da", "assets/csv/producten-da.csv"],
["de", "assets/csv/producten-de.csv"],
["en", "assets/csv/producten-en.csv"],
["es", "assets/csv/producten-es.csv"],
["fr", "assets/csv/producten-fr.csv"],
["it", "assets/csv/producten-it.csv"],
["nl", "assets/csv/producten-nl.csv"],
["sv", "assets/csv/producten-sv.csv"]
                ];

var producten = [];
var ProductsSorted = []

$(document).ready(function () {

    var filesLoaded = 0;
    for (i = 0; i < CSV_files.length; i++) {
        load_csvfile(CSV_files[i][1], function (x) {

            //save data from translation in producten[translation]
            producten[CSV_files[filesLoaded][0]] = csvJSON(x);

            filesLoaded += 1;
            //when all files are loaded...
            if (filesLoaded == CSV_files.length)
                parseData(x);
        });
    }
})

function parseData(x) {
    console.log(producten)


    var arr = [];
    var LAVPID; //LastAddedVirtualProductID

    //loop through languages
    for (h = 0; h < CSV_files.length; h++) {
        var lang = CSV_files[h][0];

        //loop through producten per language
        for (i = 0; i < producten[lang].length; i++) {
            var id = producten[lang][i].id
            var type = producten[lang][i].type
            var key = producten[lang][i].key
            var val = producten[lang][i].value

            if (type == 'VirtualProduct') {
                LAVPID = id;

                if (ProductsSorted[LAVPID] === undefined)
                    ProductsSorted[LAVPID] = [];


                if (key.indexOf('specs.') > -1) {
                    var str = key.split('.');

                    if (ProductsSorted[LAVPID]['specs'] === undefined) {
                        ProductsSorted[LAVPID]['specs'] = [];
                    }

                    if (str[1] == 'dimensions') {
                        if (ProductsSorted[LAVPID].specs[str[1]] === undefined)
                            ProductsSorted[LAVPID].specs[str[1]] = [];
                        if (ProductsSorted[LAVPID].specs[str[1]][str[2]] === undefined)
                            ProductsSorted[LAVPID].specs[str[1]][str[2]] = [];
                        if (ProductsSorted[LAVPID].specs[str[1]][str[2]][str[4]] === undefined)
                            ProductsSorted[LAVPID].specs[str[1]][str[2]][str[4]] = [];
                        ProductsSorted[LAVPID].specs[str[1]][str[2]][str[4]][lang] = val;

                    } else if (str[1] == 'features') {
                        if (ProductsSorted[LAVPID].specs[str[1]] === undefined)
                            ProductsSorted[LAVPID].specs[str[1]] = [];
                        if (ProductsSorted[LAVPID].specs[str[1]][str[2]] === undefined)
                            ProductsSorted[LAVPID].specs[str[1]][str[2]] = [];
                        ProductsSorted[LAVPID].specs[str[1]][str[2]][lang] = val;

                    } else if (str[1] == 'recommendations') {
                        if (ProductsSorted[LAVPID].specs[str[1]] === undefined)
                            ProductsSorted[LAVPID].specs[str[1]] = [];
                        ProductsSorted[LAVPID].specs[str[1]][lang] = val;

                    } else if (str[2] == 'video') {
                        if (ProductsSorted[LAVPID].specs[str[2]] === undefined)
                            ProductsSorted[LAVPID].specs[str[2]] = [];
                        ProductsSorted[LAVPID].specs[str[2]][lang] = val;
                        console.log(LAVPID)

                    }


                } else if (key.indexOf('related.') > -1) {
                    var str = key.split('.');

                    if (ProductsSorted[LAVPID]['related'] === undefined) {
                        ProductsSorted[LAVPID]['related'] = [];
                    }

                    if (ProductsSorted[LAVPID]['related'][str[1]] === undefined) {
                        ProductsSorted[LAVPID]['related'][str[1]] = [];
                    }

                    ProductsSorted[LAVPID]['related'][str[1]][str[2]] = val;



                } else {
                    if (ProductsSorted[LAVPID][key] === undefined) {
                        ProductsSorted[LAVPID][key] = [];
                    }
                    ProductsSorted[LAVPID][key][lang] = val;
                }





            } else if (type == 'VirtualProperty') {
                if (ProductsSorted[LAVPID].VirtualProperty === undefined)
                    ProductsSorted[LAVPID].VirtualProperty = [];
                if (ProductsSorted[LAVPID].VirtualProperty[id] === undefined)
                    ProductsSorted[LAVPID].VirtualProperty[id] = [];
                if (ProductsSorted[LAVPID].VirtualProperty[id][key] === undefined)
                    ProductsSorted[LAVPID].VirtualProperty[id][key] = [];

                ProductsSorted[LAVPID].VirtualProperty[id][key][lang] = val;

            } else if (type == 'VirtualOption') {
                if (ProductsSorted[LAVPID].VirtualOption === undefined)
                    ProductsSorted[LAVPID].VirtualOption = [];
                if (ProductsSorted[LAVPID].VirtualOption[id] === undefined)
                    ProductsSorted[LAVPID].VirtualOption[id] = [];
                if (ProductsSorted[LAVPID].VirtualOption[id][key] === undefined)
                    ProductsSorted[LAVPID].VirtualOption[id][key] = [];

                ProductsSorted[LAVPID].VirtualOption[id][key][lang] = val;

            } else if (type == 'Product') {
                if (ProductsSorted[LAVPID].Products === undefined)
                    ProductsSorted[LAVPID].Products = [];
                if (ProductsSorted[LAVPID].Products[id] === undefined)
                    ProductsSorted[LAVPID].Products[id] = [];
                if (ProductsSorted[LAVPID].Products[id][key] === undefined)
                    ProductsSorted[LAVPID].Products[id][key] = [];
                if (ProductsSorted[LAVPID].Products[id][key][lang] === undefined)
                    ProductsSorted[LAVPID].Products[id][key][lang] = [];

                ProductsSorted[LAVPID].Products[id][key][lang] = val;

            }

        }


    }
    fixHoles();

    console.log(ProductsSorted)

    getStats()
}

function fixHoles() {
    var x = 0;
    for (i in ProductsSorted) {
        if (ProductsSorted[i] === undefined) {
            ProductsSorted[i] = null;
        }
    }
}

function NoProducts() {
    var x = 0;
    for (i in ProductsSorted) {
        if (ProductsSorted[i].Products)
            x += Object.keys(ProductsSorted[i].Products).length
    }
    return x
}

function NoTranslations(key) {
    var x = 0;
    for (i in ProductsSorted) {
        if (ProductsSorted[i][key])
            x += Object.keys(ProductsSorted[i][key]).length
    }
    return x
}


function NoTranslations2(key1, key2) {
    var x = 0;
    for (i in ProductsSorted) {
        if (ProductsSorted[i][key1])
            if (ProductsSorted[i][key1][key2])
                x += Object.keys(ProductsSorted[i][key1][key2]).length
    }
    return x
}

function No(key) {
    var x = 0;
    for (i in ProductsSorted) {
        if (ProductsSorted[i][key])
            x++
    }
    return x
}

function No2(key1, key2) {
    var x = 0;
    for (i in ProductsSorted) {
        if (ProductsSorted[i][key1])
            if (ProductsSorted[i][key1][key2])
                x++
    }
    return x
}


function getStats() {
    console.log('aantal hoofdproducten     \t' + Object.keys(ProductsSorted).length);
    console.log('aantal producten          \t' + NoProducts())
    console.log('AVG prod. p. hoofdproduct \t' + NoProducts() / Object.keys(ProductsSorted).length);

    console.log('\n\n------------------------------------------------------------------------\n\n');
    console.log('name.content        \t' + No('name.content') + '\t translations ' + NoTranslations('name.content') + ' AVG ' + NoTranslations('name.content') / No('name.content'));
    console.log('description.content \t' + No('description.content') + '\t translations ' + NoTranslations('description.content') + ' AVG ' + NoTranslations('description.content') / No('description.content'));
    console.log('subtitle.content    \t' + No('subtitle.content') + '\t translations ' + NoTranslations('subtitle.content') + ' AVG ' + NoTranslations('subtitle.content') / No('subtitle.content'));
    console.log('kind.content        \t' + No('kind.content') + '\t translations ' + NoTranslations('kind.content') + ' AVG ' + NoTranslations('kind.content') / No('kind.content'));


    var NoProdNameTransl = 0;
    var NoProdFeatures = 0;
    var NoProdDim = 0;
    var NoRetailerOpm = 0;
    var NoRetailerOpmTR = 0;
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].specs != undefined) {
                if (ProductsSorted[i].specs.features != undefined) {
                    NoProdFeatures++
                }
                if (ProductsSorted[i].specs.dimensions != undefined) {
                    NoProdDim++
                }

            }
            if (ProductsSorted[i]['retailer_remarks.content'] != undefined) {
                console.log(ProductsSorted[i]['retailer_remarks.content'])
                console.log(Object.keys(ProductsSorted[i]['retailer_remarks.content']))
                console.log(Object.keys(ProductsSorted[i]['retailer_remarks.content']).length)
                NoRetailerOpm++;

                NoRetailerOpmTR += Object.keys(ProductsSorted[i]['retailer_remarks.content']).length
            }

            if (ProductsSorted[i].Products != undefined) {
                for (j = 0; j < Object.keys(ProductsSorted[i].Products).length; j++) {
                    //console.log(ProductsSorted[i].Products)
                    NoProdNameTransl += Object.keys(ProductsSorted[i].Products[Object.keys(ProductsSorted[i].Products)[j]]['product_names.name']).length;
                }
            }
        }
    }

    console.log('NoProdNameTransl: ' + NoProdNameTransl);
    console.log('NoProdFeatures: ' + NoProdFeatures);
    console.log('NoProdDim: ' + NoProdDim);
    console.log('NoRetailerOpm: ' + NoRetailerOpm);
    console.log('NoRetailerOpmTR: ' + NoRetailerOpmTR);
    console.log('\n\n--------------------------VirtualProperties------------------------------\n\n');

    var VirtualProperties = {
        name: [],
        title: [],
        introtext: [],
        nametr: 0,
        titletr: 0,
        introtexttr: 0
    }
    var NoVP = 0;;
    //loop through products
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].VirtualProperty != undefined) {
                //loop through VirtualProperties
                NoVP += Object.keys(ProductsSorted[i].VirtualProperty).length
                for (j = 0; j < Object.keys(ProductsSorted[i].VirtualProperty).length; j++) {

                    var VirtualProperty = ProductsSorted[i].VirtualProperty[Object.keys(ProductsSorted[i].VirtualProperty)[j]]

                    if (VirtualProperty['name.content'] != undefined) {
                        VirtualProperties.name.push(String(VirtualProperty['name.content'].en))
                        VirtualProperties.nametr += Object.keys(VirtualProperty['name.content']).length
                    }
                    if (VirtualProperty['title.content'] != undefined) {
                        VirtualProperties.title.push(String(VirtualProperty['title.content'].en))
                        VirtualProperties.titletr += Object.keys(VirtualProperty['title.content']).length
                    }
                    if (VirtualProperty['introtext.content'] != undefined) {
                        VirtualProperties.introtext.push(String(VirtualProperty['introtext.content'].en))
                        VirtualProperties.introtexttr += Object.keys(VirtualProperty['introtext.content']).length
                    }
                }
            }
        }
    }
    VirtualProperties.name.sort()
    VirtualProperties.title.sort()
    VirtualProperties.introtext.sort()
    console.log('-------------------------------VirtualProperties.name-------Most-Used')
    for (i = 0; i < VirtualProperties.name.length; i++)
        console.log(VirtualProperties.name[i])
    console.log('-------------------------------VirtualProperties.title------Most-Used')
    for (i = 0; i < VirtualProperties.title.length; i++)
        console.log(VirtualProperties.title[i])
    console.log('-------------------------------VirtualProperties.introtext--Most-Used')
    for (i = 0; i < VirtualProperties.introtext.length; i++)
        console.log(VirtualProperties.introtext[i])

    console.log('Virtual Properties total: \t' + NoVP)
    console.log('name.content      \t' + VirtualProperties.name.length + '\t translations \t' + VirtualProperties.nametr + ' AVG ' + VirtualProperties.nametr / VirtualProperties.name.length)
    console.log('title.content     \t' + VirtualProperties.title.length + '\t translations \t' + VirtualProperties.titletr + ' AVG ' + VirtualProperties.titletr / VirtualProperties.title.length)
    console.log('introtext.content \t' + VirtualProperties.introtext.length + '\t translations \t' + VirtualProperties.introtexttr + ' AVG ' + VirtualProperties.introtexttr / VirtualProperties.introtext.length)
    //VirtualProperties
    //No. VirtualProperties
    //AVG VirtualProperties per hoofdproduct
    //AVG no. translations VirtualProperties

    console.log('\n\n--------------------------VirtualOpti0ns---------------------------------\n\n');
    var VirtualOptions = []
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].VirtualProperty != undefined) {
                for (j = 0; j < Object.keys(ProductsSorted[i].VirtualOption).length; j++) {
                    VirtualOptions.push(Object.keys(ProductsSorted[i].VirtualOption)[j])
                }
            }
        }
    }

    console.log('name.content      \t' + No2('VirtualOption', 'name.content') + '\t translations \t' + NoTranslations2('VirtualOption', 'name.content') + ' AVG ' + NoTranslations2('VirtualOption', 'name.content') / No2('VirtualOption', 'name.content'))
    //VirtualProperties
    //No. VirtualProperties
    //AVG VirtualProperties per hoofdproduct
    //AVG no. translations VirtualProperties



    console.log('\n\n--------------------------Specs---------------------------------\n\n');
    //dimentions features recommendations video
    var NoFeatures = 0;
    var NoFeaturesTransl = 0;
    var NoDimentions = 0;
    var NoDimentionsTransl = 0;
    var NoRecommendations = 0;
    var NoRecommendationsTransl = 0;
    var NoVideos = 0;
    var NoVideosTransl = 0;

    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].specs != undefined) {

                //loop through features
                if (ProductsSorted[i].specs.features != undefined) {
                    for (j = 0; j < ProductsSorted[i].specs.features.length; j++) {
                        NoFeatures++;
                        NoFeaturesTransl += Object.keys(ProductsSorted[i].specs.features[j]).length
                    }
                }
                //loop through dimentions
                if (ProductsSorted[i].specs.dimensions != undefined) {
                    for (j = 0; j < ProductsSorted[i].specs.dimensions.length; j++) {
                        NoDimentions++;
                        NoDimentionsTransl += Object.keys(ProductsSorted[i].specs.dimensions[j]).length
                    }
                }
                //count through recommendations
                if (ProductsSorted[i].specs.recommendations != undefined) {

                    NoRecommendations++;
                    NoRecommendationsTransl += Object.keys(ProductsSorted[i].specs.recommendations).length

                }
                //count through videos
                if (ProductsSorted[i].specs.video != undefined) {
                    NoVideos++;
                    NoVideosTransl += Object.keys(ProductsSorted[i].specs.video).length

                }
            }
        }
    }

    console.log('NoFeatures                 ' + NoFeatures + ' tr ' + NoFeaturesTransl + ' AVG ' + NoFeaturesTransl / NoFeatures);
    console.log('NoDimentions               ' + NoDimentions + ' tr ' + NoDimentionsTransl + ' AVG ' + NoDimentionsTransl / NoDimentions);
    console.log('NoRecommendations          ' + NoRecommendations + ' tr ' + NoRecommendationsTransl + ' AVG ' + NoRecommendationsTransl / NoRecommendations);
    console.log('NoVideos                   ' + NoVideos + ' tr ' + NoVideosTransl + ' AVG ' + NoVideosTransl / NoVideos);

    FindPatterns();
}

function FindPatterns() {
    console.log('\n\n--------------------------Patterns in product---------------------------------\n\n');
    console.log('\n\n----------------------Overeenkomsten desciption en subtitle-----------------------\n\n');

    var Similarities = [];
    var descriptions = [];
    var sutbtitles = [];
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i]['description.content']) {
                descriptions.push(ProductsSorted[i]['description.content'].en)
                if (ProductsSorted[i]['subtitle.content']) {
                    sutbtitles.push(ProductsSorted[i]['subtitle.content'].en)
                    if (ProductsSorted[i]['description.content'].en == ProductsSorted[i]['subtitle.content'].en) {
                        Similarities.push(i);
                    }
                }
            }
        }
    }

    console.log('Similarities between description and subtitle: \t' + Similarities.length);
    //descriptions.sort()
    //sutbtitles.sort()
    console.log('descriptions')
    for (i = 0; i < descriptions.length; i++) {
        //console.log(descriptions[i])
    }
    console.log('sutbtitles')
    for (i = 0; i < sutbtitles.length; i++) {
        console.log(sutbtitles[i] + '\n' + descriptions[i] + '\n\n')
    }
    console.log('\n\n--------------------------------Patterns in Kind-----------------------------------\n\n');
    var kinds = [];
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i]['kind.content']) {
                kinds.push(ProductsSorted[i]['kind.content'].en);
            }
        }
    }
    kinds.sort();
    for (i = 0; i < kinds.length; i++) {
        console.log(kinds[i])
    }

    //hoevaak ingevuld?
    //top x meest gebruikte?

    console.log('\n\n-------------------------------VirtualProperties----------------------------------\n\n');
    //Product opties
    //top x meest gebruikte?
    var VirtualProperties = [];
    var VirtualPropertiesKeys = [];
    var NoVP = 0; //number of virtual properties per Hproduct

    //loop through products
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].VirtualProperty != undefined) {
                //loop through VirtualProperties
                NoVP += Object.keys(ProductsSorted[i].VirtualProperty).length
                for (j = 0; j < Object.keys(ProductsSorted[i].VirtualProperty).length; j++) {

                    var VirtualProperty = ProductsSorted[i].VirtualProperty[Object.keys(ProductsSorted[i].VirtualProperty)[j]]

                }
            }
        }
    }

    VirtualProperties.sort();
    VirtualPropertiesKeys.sort();
    for (i = 0; i < VirtualProperties.length; i++) {
        //console.log(VirtualProperties[i])
    }
    for (i = 0; i < VirtualPropertiesKeys.length; i++) {
        //console.log(VirtualPropertiesKeys[i])
    }
    console.log('NoVP ' + NoVP)

    console.log('\n\n---------------------------------VirtualOptions-----------------------------------\n\n');
    //Product opties
    //top x meest gebruikte?
    var VirtualOptions = [];
    var VirtualOptionsTranslations = 0;
    var NoVO = 0; //number of VirtualOptions per Hproduct

    //loop through products
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].VirtualOption != undefined) {
                //loop through VirtualOptions
                NoVO += Object.keys(ProductsSorted[i].VirtualOption).length;
                for (j = 0; j < Object.keys(ProductsSorted[i].VirtualOption).length; j++) {
                    var index = Object.keys(ProductsSorted[i].VirtualOption)[j]

                    var VirtualOption = ProductsSorted[i].VirtualOption[index]['name.content'].en
                    VirtualOptions.push(VirtualOption);
                    VirtualOptionsTranslations += Object.keys(ProductsSorted[i].VirtualOption[index]['name.content']).length
                }
            }
        }
    }

    VirtualOptions.sort();
    for (i = 0; i < VirtualOptions.length; i++) {
        console.log(VirtualOptions[i])
    }
    console.log('NoVO ' + NoVO)
    console.log('NoVOTR ' + VirtualOptionsTranslations)

    console.log('\n\n---------------------------------Specs -------------------------------------------\n\n');
    console.log('\n\n---------------------------------Specs.features-----------------------------------\n\n');
    //top x meest gebruikte
    //Product opties
    //top x meest gebruikte?
    var Features = [];
    var NoF = 0; //number of VirtualOptions per Hproduct

    //loop through products
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].specs != undefined) {
                if (ProductsSorted[i].specs.features != undefined) {
                    //loop through VirtualOptions
                    NoF += Object.keys(ProductsSorted[i].specs.features).length;
                    for (j = 0; j < Object.keys(ProductsSorted[i].specs.features).length; j++) {
                        var index = Object.keys(ProductsSorted[i].specs.features)[j]

                        var Feature = ProductsSorted[i].specs.features[index].en
                        Features.push(Feature);
                    }
                }
            }
        }
    }

    Features.sort();
    for (i = 0; i < Features.length; i++) {
        //console.log(Features[i])
    }

    console.log('NoF: ' + NoF);
    console.log('\n\n---------------------------------Specs.dimentions----------------------------------\n\n');
    //top x meest gebruikte
    //Product opties
    //top x meest gebruikte?
    var dimensions = [];
    var NoD = 0; //number of VirtualOptions per Hproduct

    //loop through products
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {

            //console.log(ProductsSorted[i]);
            if (ProductsSorted[i].specs != undefined) {

                if (ProductsSorted[i].specs.dimensions != undefined) {

                    NoD += Object.keys(ProductsSorted[i].specs.dimensions).length;
                    for (j = 0; j < Object.keys(ProductsSorted[i].specs.dimensions).length; j++) {
                        var index = Object.keys(ProductsSorted[i].specs.dimensions)[j]

                        for (k = 0; k < ProductsSorted[i].specs.dimensions[j].length; k++) {
                            var dimension = ProductsSorted[i].specs.dimensions[j][k].en;
                            dimensions.push(dimension);
                        }

                    }
                }
            }
        }
    }

    dimensions.sort();
    for (i = 0; i < dimensions.length; i++) {
        //console.log(dimensions[i])
    }
    console.log('NoD ' + NoD)
    console.log('\n\n---------------------------------Specs.recommendations-----------------------------\n\n');

    var recommendations = [];
    var NoR = 0; //number of VirtualOptions per Hproduct

    //loop through products
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].specs != undefined) {
                if (ProductsSorted[i].specs.recommendations != undefined) {
                    //loop through VirtualOptions
                    NoR++;
                    recommendations.push(ProductsSorted[i].specs.recommendations.en)
                }
            }
        }
    }

    recommendations.sort();
    for (i = 0; i < recommendations.length; i++) {
        //console.log(recommendations[i])
    }
    console.log('NoR ' + NoR)
    console.log('\n\n---------------------------------Specs.videos-------------------------------------\n\n');

    var videos = [];
    var NoV = 0; //number of VirtualOptions per Hproduct

    //loop through products
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].specs != undefined) {
                if (ProductsSorted[i].videos != undefined) {
                    //loop through VirtualOptions
                    NoV++
                    videos.push(ProductsSorted[i].videos)
                }
            }
        }
    }

    videos.sort();
    for (i = 0; i < videos.length; i++) {
        console.log(videos[i])
    }
    console.log('NoV ' + NoV)

    console.log('\n\n---------------------------------Related-------------------------------------\n\n');

    var related = [];
    var NoRelated = 0; //number of VirtualOptions per Hproduct

    //loop through related products
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].related != undefined) {
                NoRelated += Object.keys(ProductsSorted[i].related).length
                for (j = 0; j < Object.keys(ProductsSorted[i].related).length; j++) {
                    related.push(ProductsSorted[i].related[Object.keys(ProductsSorted[i].related)[j]])
                }
            }
        }
    }

    related.sort();
    for (i = 0; i < related.length; i++) {
        console.log(related[i])
    }
    console.log('NoRelated ' + NoRelated)

    console.log('\n\n---------------------------------Balance options and products-------------------------------------\n\n');

    var NoUnbalancedProducts = 0;
    //loop through products
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].Products != undefined) {
                if (ProductsSorted[i].VirtualOption != undefined) {
                    if (Object.keys(ProductsSorted[i].Products).length != ProductsSorted[i].VirtualOption.length) {
                        NoUnbalancedProducts++;
                    }
                }
            }
        }
    }

    console.log(NoUnbalancedProducts)




    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i]['name.content'] != undefined && ProductsSorted[i]['kind.content'] != undefined && ProductsSorted[i]['description.content'] != undefined) {
                //console.log(ProductsSorted[i]['name.content'].en + ' \n' + ProductsSorted[i]['kind.content'].en + ' \n' + ProductsSorted[i]['description.content'].en + '\n\n');
            }
        }
    }

    var templateImpact = 0;
    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] != undefined) {
            if (ProductsSorted[i].Products != undefined && ProductsSorted[i].VirtualOption != undefined) {

                var HprodName = ProductsSorted[i]['name.content'].en.toLowerCase();

                //loop door opies
                for (j = 0; j < Object.keys(ProductsSorted[i].VirtualOption).length; j++) {

                    var optie = ProductsSorted[i].VirtualOption[Object.keys(ProductsSorted[i].VirtualOption)[j]]['name.content'].en.toLowerCase()
                    var gelukt = false;
                    var productnamen = [];
                    for (k = 0; k < Object.keys(ProductsSorted[i].Products).length; k++) {
                        var productnaam = ProductsSorted[i].Products[Object.keys(ProductsSorted[i].Products)[k]]['product_names.name'].en.toLowerCase()
                        if (productnaam.indexOf(optie) > -1) {
                            if (productnaam.indexOf(HprodName) > -1) {
                                //console.log(productnaam + '\t |\t ' + HprodName + '\t |\t ' + optie)
                                //k = Object.keys(ProductsSorted[i].Products).length;
                                gelukt = true;
                                templateImpact++;
                            } else {
                                productnamen.push(productnaam)
                                console.log('Hprod name: \t' + HprodName + '\t optie \t' + optie + ' \t productnamen: \t' + JSON.stringify(productnamen))
                            }
                        }
                    }
                    if (!gelukt) {
                        //console.log(HprodName + ' - \t |\t ' + optie + ' \t producten: ' + JSON.stringify(productnamen))
                    }
                }

            }
        }
    }
    console.log(templateImpact)

    for (i = 0; i < ProductsSorted.length; i++) {
        if (ProductsSorted[i] && ProductsSorted[i]['name.content'] && ProductsSorted[i].Products) {
            console.log(Object.keys(ProductsSorted[i].Products).length + '\t' + ProductsSorted[i]['name.content'].en)
        }
    }


    var ondertitels = [];
    var soorten = [];
    var omschrijvingen = [];
    var namen = [];
    var retailer_opmerkingen = [];

    for (a = 0; a < ProductsSorted.length; a++) {
        if (ProductsSorted[a]) {
            var ondertitel = '';
            var soort = '';
            var omschrijving = '';
            var naam = '';
            var retailer_opmerking = '';

            if (ProductsSorted[a]['subtitle.content']) {
                ondertitel = ProductsSorted[a]['subtitle.content'].en
            }
            if (ProductsSorted[a]['kind.content']) {
                soort = ProductsSorted[a]['kind.content'].en
            }
            if (ProductsSorted[a]['description.content']) {
                omschrijving = ProductsSorted[a]['description.content'].en
            }
            if (ProductsSorted[a]['name.content']) {
                naam = ProductsSorted[a]['name.content'].en
            }
            if (ProductsSorted[a]['retailer_remarks.content']) {
                retailer_opmerking = ProductsSorted[a]['retailer_remarks.content'].en
            }

            ondertitels.push(ondertitel)
            soorten.push(soort)
            omschrijvingen.push(omschrijving)
            namen.push(naam)
            retailer_opmerkingen.push(retailer_opmerking)

            console.log('naam               ' + naam + '\n' +
                'soort              ' + soort + '\n' +
                'omschrijving       ' + omschrijving + '\n' +
                'ondertitel         ' + ondertitel + '\n' +
                'retailer_opmerking ' + retailer_opmerking + '\n\n\n')
        }
    }
}
